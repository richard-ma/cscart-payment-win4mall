<?php
//zencart
//
  define('MODULE_PAYMENT_CCWONLINE_TEXT_ADMIN_TITLE', 'Wintopay Gateway[credit card]v1.3.8'); //version_interface
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE', 'Carta di credito on-line Gateway');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_DESCRIPTION', 'Payment_ccwonline Gateway');
  
  define('MODULE_PAYMENT_CCWONLINE_MARK_BUTTON_IMG', DIR_WS_MODULES . 'payment/ONLINE/ONLINE.gif');
  define('MODULE_PAYMENT_CCWONLINE_PAY_BUTTON_IMG', DIR_WS_MODULES . 'payment/ONLINE/ONLINE_submit_button.gif');
  define('MODULE_PAYMENT_CCWONLINE_PAY_BUTTON_ALT', 'Go to checkout with Payment_ccwonline');
  define('MODULE_PAYMENT_CCWONLINE_MARK_BUTTON_ALT', 'Checkout with Payment_ccwonline');
  define('MODULE_PAYMENT_CCWONLINE_ACCEPTANCE_MARK_TEXT', 'Credit card Payment<br/>');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_LOGO', '<img src="' . MODULE_PAYMENT_CCWONLINE_MARK_BUTTON_IMG . '" alt="' . MODULE_PAYMENT_CCWONLINE_MARK_BUTTON_ALT . '" title="' . MODULE_PAYMENT_CCWONLINE_MARK_BUTTON_ALT . '" />'.MODULE_PAYMENT_CCWONLINE_ACCEPTANCE_MARK_TEXT );

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_1_1', 'Enable Payment_ccwonline Module');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_1_2', 'Do you want to accept Payment_ccwonline payments?</br>');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_2_1', 'Payment_ccwonline Number');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_2_2', 'Merchant Number');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_3_1', 'Payment_ccwonline MD5 key');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_3_2', 'Merchant md5key');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_4_1', 'Currency');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_4_2', 'Currency Type: 1-USD, 2-EUR,3-CNY,4-GBP');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_5_1', 'Language');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_5_2', 'Language: 1-Chinese, 2-English, 3-Français,4-Español,5-Deutsch,6-わご');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_6_1', 'Payment Zone');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_6_2', 'If a zone is selected, only enable this payment method for that zone.');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_7_1', 'Set Pending Notification Status');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_7_2', 'Set the status of orders made with this payment module to this value<br />(Not Payment recommended)');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_8_1', 'Sort order of display');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_8_2', 'Sort order of display. Lowest is displayed first.');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_9_1', 'Payment_ccwonline transaction URL<br />Default: <code>https://payment.wintopay.com/onlinepayByWin</code><br />');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_9_2', 'Payment_ccwonline transaction URL');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_10_1', 'Payment_ccwonline Return URL');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_10_2', 'Payment_ccwonline Return URL');

  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_11_1', 'Filished order status');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_11_2', 'Set your order status for order filished<br />(Processing  recommended)');

  //cdn js
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_1', 'Cdn js ,Locate the customer IP');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_2', 'when you website on cdn( default disable)');
  //card type
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_1', 'Card support type');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_2', 'The payment pages display icon photo');

  
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_CHECKNUMBER_LOCATION','<img src="images/picture.jpg" width="40" height="30"/>');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_ACCEPT','Accettiamo:');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_FIRSTNAME','<i>*</i>Nome:');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_LASTNAME','<i>*</i>Cognome:');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_NUMBER','<i>*</i>Numero Di Carta');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_EXPIRES','<i>*</i>Data Di Scadenza:'); 
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_CHECKNUMBER','<i>*</i>CVC/CVV2:'); 
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_LOGO','Credit Card Payment');
   define('MODULE_PAYMENT_CCWONLINE_TEXT_JS_CC_OWNER','* Il nome del titolare della carta deve essere almeno ' . CC_OWNER_MIN_LENGTH . ' personaggi.\n');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_JS_CC_NUMBER','* Il numero di carta di credito deve essere almeno ' . CC_NUMBER_MIN_LENGTH . ' personaggi.\n');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_JS_CC_CVV','* È necessario inserire il numero di 3 o 4 cifre sul retro della carta di credito');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CARDBANK','*emittente Bank');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_Country','*paese');
  define('MODULE_PAYMENT_CCWONLINE_TEXT_CARDTYPE','*tipo di carta');
  
  define('MODULE_ZHU','*Emittente Bank è richiesto il nome della banca che ha emesso la carta di credito (egMBNA America del Bank)');
  define('MODULE_CARDBANK','*Nome sulla carta');
  
  
?>
