﻿<?php
/**
* @author       wintopay
* @copyright    wintopay.com
* @since        v1.0
*/

header("Content-type: text/html;charset=utf-8;");
error_reporting(0);

//异步接收
$billno = isset($_REQUEST['billno'])?$_REQUEST['billno']:null;  			//订单号
$currency = isset($_REQUEST['currency'])?$_REQUEST['currency']:null;		//币种
if(!$currency) $currency = isset($_REQUEST['currency_name'])?$_REQUEST['currency_name']:null;		//币种
$amount = isset($_REQUEST['amount'])?$_REQUEST['amount']:null;				//金额
$succeed = isset($_REQUEST['succeed'])?$_REQUEST['succeed']:null;			//订单支付结果 1=成功, 0=失败
$orderinfo = isset($_REQUEST['orderinfo'])?$_REQUEST['orderinfo']:null;		//订单支付信息
$md5info = isset($_REQUEST['md5info'])?$_REQUEST['md5info']:null;			//数据校验 BillNo +Currency +Amount +Succeed+MD5key的md5加密串

$ptype = isset($_REQUEST['ptype'])?$_REQUEST['ptype']:null;
					$order_id = isset($_REQUEST['order_id'])? (int)$_REQUEST['order_id']:null;
					$paymentinfo = isset($_REQUEST['paymentinfo'])?$_REQUEST['paymentinfo']:null;


//推送
if($billno and $currency and $amount and $md5info and $orderinfo)
{
			$md5str = $billno.$currency.$amount.$succeed.MODULE_PAYMENT_CCWONLINE_MD5KEY;
			$md5sing = md5($md5str);
			$md5info = strtolower($md5info);
			$md5sing = strtolower($md5sing);
			if($md5sing == $md5info)
			{
				//
		//订单信息
				require(DIR_WS_CLASSES . 'order.php');
				$order = new order;
				$order->order($billno);

				//print_r($order);
				//币种得到是如 USD , EUR
				$order_currency = isset($order->info['currency']) ? $order->info['currency']:null;
				//都转成大写的
				$order_currency = strtoupper($order_currency);
				$currency = strtoupper($currency);
				if(!$order_currency)
				{
					die('invalid');   //无此订单号在网站上
				}else
				{
					$order_amount = number_format(($order->info['total']) * $order->info['currency_value'], 2, '.', '');

					//echo $amount. $order_amount . $currency .$order_currency;
					//对比数据
					if( $amount == $order_amount and $currency == $order_currency  )
					{
						  
						 //更新订单状态
						//支付失败状态
						$payment_declined=831;
						$payment_pendingwin=819;
						switch ($succeed) 
						{
								case '1':
								 //成功
										$statebyONLINE=MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_FILISHED_ID;
											$sql_data_array = array (
											'orders_status_id' => $statebyONLINE,
											'date_added' => 'now()',
											'customer_notified' => 1,
											'comments'=>':Payment Success ',
											'orders_id' => (int)$billno
											);
									
										$sql_data_order=array(
											'orders_status'=>$statebyONLINE
										);

									break;
								default:
									//失败
										$sql_data_array = array (
											'orders_status_id' => $payment_declined,
											'date_added' => 'now()',

											'customer_notified' => 0,
											'comments'=>':payment fail'.$succeed . $orderinfo ,
											'orders_id' => (int)$billno
										);
										$sql_data_order=array(
											'orders_status'=>$payment_declined
										);
										$order->info['order_status']=$payment_declined;

									break;
						}
						//更新状态和记录状态 update ,or  insert
						zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $billno);
						zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'insert' );
						//zen_redirect(zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO,'','SSL') . '&order_id=' . $billno);//支付失败
						
						//发送邮件给顾客
						$order->send_order_email($billno,2);

					}else
					{
						die('invalid');   //订单信息与网站上的不同
					}
				}
				
//	

				echo 'success';
				exit;
			}else
			{
				die('md5_sign_error');
			}
	exit;
}

//重置通知
$messageStack->reset();

//显示支付结果 相对应的说明
//只用显示相关说明 。不用更新状态
if($ptype and $order_id){
				switch ($ptype)
				{
					case 'fail': 

							$html_out = '<br/><div><b>'. strip_tags( urldecode($paymentinfo) ) .'</b></div>
								<br/>
								Order ID: '.$order_id.'
								<br/>
								Payment fail.
								<div>
								<ul>
								<li><a href="'. zen_href_link(FILENAME_ACCOUNT) .'">Go to My Account</a></li>
								<li><a href="'.zen_href_link(FILENAME_SHOPPING_CART) .'">Shipping cart</a></li>
								</ul>
								</div>';
								//caution error success warning
							$messageStack->add('checkout_payresult_info', $html_out,'caution');	
							 
						break;
					case 'processing':

							$html_out = '<br/><div><b>'. strip_tags( urldecode($paymentinfo) ) .'</b></div>
								<br/>
								Order ID: '.$order_id.'
								<br/>
								The order has been successfully submitted. Waiting payment processing and the payment result will be sent your email.
								<div>
								<ul>
								<li><a href="'. zen_href_link(FILENAME_ACCOUNT) .'">Go to My Account</a></li>
								<li><a href="'.zen_href_link(FILENAME_SHOPPING_CART) .'">Shipping cart</a></li>
								</ul>
								</div>';
								//caution error success warning
							$messageStack->add('checkout_payresult_info', $html_out,'success');	
							 
						break;
				}
	return false;
}


if (isset ($zco_notifie))
	$zco_notifier->notify('NOTIFY_HEADER_START_CHECKOUT_PAYRESULT');

require (DIR_WS_MODULES . zen_get_module_directory('require_languages.php'));

// 发送邮件没有得到语言包内的定义
if( file_exists( DIR_WS_LANGUAGES . $_SESSION['language'].'/checkout_process.php') )
{
	require_once( DIR_WS_LANGUAGES . $_SESSION['language'].'/checkout_process.php' );
}else
{
	if( file_exists( DIR_WS_LANGUAGES . 'english/checkout_process.php') )
	{
		require_once( DIR_WS_LANGUAGES . 'english/checkout_process.php' );
	}
}

////////////////////////////////////////////////////////////////////

//获得接口返回数据
$BillNo = $_POST['BillNo'];
$Currency = $_POST['Currency'];
$Amount = $_POST['Amount'];
$Succeed = $_POST['Succeed'];
$Result = $_POST['Result'];
$MD5info = $_POST['MD5info'];
$MD5key = MODULE_PAYMENT_CCWONLINE_MD5KEY;
$md5src = $BillNo . $Currency . $Amount . $Succeed . $MD5key;
$md5sign = strtoupper(md5($md5src));

//支付失败状态
$payment_declined=831;
$payment_pendingwin=819;

//echo "<br/>md5sign:".$md5sign;
//基本验证
if ($MD5info == $md5sign) {
	//echo "<br/>md5sign:".$md5sign;
	if ($Currency == '1')
		$Currency = 'USD';
	else if($Currency=='2'){
		$Currency = 'EUR';
	}else if($Currency=='4'){
		$Currency = 'GBP';
	}else if($Currency=='3'){
		$Currency = 'CNY';
	}else{

	}
/*
	$orders_query = "SELECT * FROM " . TABLE_ORDERS . "
																					 WHERE customers_id = :customersID
																					 ORDER BY date_purchased DESC LIMIT 1";
	$orders_query = $db->bindVars($orders_query, ':customersID', $_SESSION['customer_id'], 'integer');
	$orders = $db->Execute($orders_query);
	$orders_id = $orders->fields['orders_id']; //该顾客在商户网站中的最新订单号
	$curr = $orders->fields['currency']; //该订单的币种
	$orders_total = $orders->fields['order_total']; //该订单的总金额

	//判断用户最后一张订单是否是当前所支付的订单
	if ($orders_id == $BillNo && trim($curr) == $Currency && $Amount == $orders_total) {
*/
		//是否成功支付'88'表示支付成功 19表示银行待处理
		if ($Succeed == '88' || $Succeed == '19' ) {
			$messageStack->add('checkout_payresult', '<br/>Your Order Number :' . $BillNo . '<br/>Amount:' . $_SESSION['CustomerAmount'] ." ".$_SESSION['currency'].'<br/>Payment Result:' . $Result, 'success');
			
			if($Succeed == '88'){
				$statebywinpay=MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_FILISHED_ID;
				$sql_data_array = array (
				'orders_status_id' => $statebywinpay,
				'date_added' => 'now()',
				'customer_notified' => 1,
				'comments'=>'Payment Success'
			);
			$sql_data_order=array(
				'orders_status'=>$statebywinpay
			);
			}else{
				$statebywinpay=$payment_pendingwin;
				$sql_data_array = array (
				'orders_status_id' => $statebywinpay,
				'date_added' => 'now()',
				'customer_notified' => 1,
				'comments'=>'wait bank processing'
			);
			$sql_data_order=array(
				'orders_status'=>$statebywinpay
			);
			}

			require(DIR_WS_CLASSES . 'order.php');
			$order = new order;
			
            require(DIR_WS_CLASSES . 'order_total.php');
			$order_total_modules = new order_total;
			require(DIR_WS_CLASSES . 'payment.php');
			$paymentsf=new payment;  
			$paymentsm=$paymentsf->payment('payment_ccwonline');  
			$order_totals = $order_total_modules->process();
		/* 	$order->create_add_products($BillNo);*/
			$order->info['payment_module_code'] ='payment_ccwonline';
			$order->fields['payment_method'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['title'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['order_status']=$statebywinpay;
			zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $BillNo);
			//修改订单状态
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'update', 'orders_id=' . (int) $BillNo);	
			$order->products_ordered='';
			for ($i=0; $i<sizeof($order->products)&&$i<=50; $i++) {
	$order->products_ordered.=
      '<tr>' . "\n" .
      '<td class="product-details" align="right" valign="top" width="30">' . $order->products[$i]['qty'] . '&nbsp;x</td>' . "\n" .
      '<td class="product-details" valign="top">' . nl2br($order->products[$i]['name']) . ($order->products[$i]['model'] != '' ? ' (' . nl2br($order->products[$i]['model']) . ') ' : '') . "\n" .
      '<nobr>' .
      '<small><em> '. nl2br($order->products_ordered_attributes) .'</em></small>' .
      '</nobr>' .
      '</td>' . "\n" .
      '<td class="product-details-num" valign="top" align="right">' .
      $currencies->display_price($order->products[$i]['final_price'], $order->products[$i]['tax'], $order->products[$i]['qty']) .
      ($order->products[$i]['onetime_charges'] !=0 ?
      '</td></tr>' . "\n" . '<tr><td class="product-details">' . nl2br(TEXT_ONETIME_CHARGES_EMAIL) . '</td>' . "\n" .
      '<td>' . $currencies->display_price($order->products[$i]['onetime_charges'], $order->products[$i]['tax'], 1) : '') .
      '</td></tr>' . "\n";
			}
			$order->send_order_email($BillNo,2);  //客户填完订单以后直接发送EMAIL，没有任何处理

			//重置购物车
			$_SESSION['cart']->reset(true);

			//清空订单id记录
			unset ($_SESSION['_winpay_order_id']);
			unset ($_SESSION['sendto']);
			unset ($_SESSION['billto']);
			unset ($_SESSION['shipping']);
			unset ($_SESSION['payment']);
			unset ($_SESSION['comments']);
			//echo "end";
		} else {

			$messageStack->add('checkout_payresult', '<br/>Your Order Number :' . $BillNo . '<br/>Amount:' . $_SESSION['CustomerAmount'] ." ".$_SESSION['currency'].'<small text-transform="none">Pay result:'.$Result.'<br/><br/><font color="#001633">'." Error ID:<b>".$Succeed."</b></font><br/></small>");

			$sql_data_array = array (
				'orders_status_id' => $payment_declined,
				'date_added' => 'now()',
				'customer_notified' => 0,
				'comments'=>$Result.'_id:'.$Succeed
			);
			$sql_data_order=array(
				'orders_status'=>$payment_declined
			);

			zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $BillNo);

			//修改订单状态
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'update', 'orders_id=' . (int) $BillNo);

		}
} else {
		 if($BillNo  and $MD5info)
		 {	
			$messageStack->add('checkout_payresult', '<small text-transform="none">Pay result:verification failed'.'<br/><br/><font color="#001633">'." Error ID:<b>".$Succeed."</b></font><br/></small>");

			$sql_data_array = array (
						'orders_status_id' => $payment_declined,
						'date_added' => 'now()',
						'customer_notified' => 0,
						'comments'=>$Result.'_id:'.$Succeed
					);
			$sql_data_order=array(
						'orders_status'=>$payment_declined
					);

			zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $BillNo);
			//修改订单状态
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'update', 'orders_id=' . (int) $BillNo);
		 }

}

?>