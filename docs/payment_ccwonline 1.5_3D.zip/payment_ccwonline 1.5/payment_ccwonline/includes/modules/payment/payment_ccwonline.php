<?php
error_reporting(0);
// date_default_timezone_set('PRC');
class payment_ccwonline {
	//
	var $code, $title, $description, $enabled, $sort_order, $form_action_url,$token;
	
	//
	var $order_pending_status = 1;
	//
	var $order_status = 1;
	var $order_id, $Amount;
	var $pay_status=array();//array(array('1'=>"No Payment",'2'=>"未支付"),array('1'=>"Payment Declined",'2'=>"支付失败"));
	var $pay_support_currency = array('USD'=>'1','EUR'=>'2','RMB'=>'3','GBP'=>'4','HKD'=>'5','JPY'=>'6','AUD'=>'7','NOK'=>'8','SGD'=>'10','CAD'=>'11','SEK'=>'12','DKK'=>'13','NZD'=>'14','TWD'=>'15');

	function payment_ccwonline() {
		global $order,$token;
		$token= $this->uuid();
	  	$this->refrech_status = 0;
		$this->code = 'payment_ccwonline';
		if ($_GET['main_page'] != '') {
			$this->title = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;

		} else {
			$this->title = MODULE_PAYMENT_CCWONLINE_TEXT_ADMIN_TITLE;
		}
		$this->description = MODULE_PAYMENT_CCWONLINE_TEXT_DESCRIPTION;
		$this->sort_order = MODULE_PAYMENT_CCWONLINE_SOTR_ORDER;
		$this->enabled = ((MODULE_PAYMENT_CCWONLINE_STATUS == 'True') ? true : false);
 		if ((int) MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_ID > 0)
 		$this->order_status = MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_ID;
		if (is_object($order)) {
			$this->update_status();
		}
		$this->form_action_url = MODULE_PAYMENT_CCWONLINE_HANDLER;
		}

	function __construct() {
		$get_module_val = isset($_GET['module']) ?$_GET['module'] :null;
		if( $get_module_val == 'payment_ccwonline' and isset($_SESSION['admin_id']) )
		{
			
			$html_out_currency = '';
			require(DIR_WS_CLASSES . 'currencies.php');
  			$currencies = new currencies(); 
  			foreach ($currencies->currencies as $key => $value)
  			{
  				  if(!isset($this->pay_support_currency[$key])) $html_out_currency.=$key. ' 支付系统不支持, ';
  			}
  			if($html_out_currency and isset($this->pay_support_currency[DEFAULT_CURRENCY])) $html_out_currency.=' <strong>如果顾客选择的不支持的币种才转成 '.DEFAULT_CURRENCY . '进行交易 .</strong>';
  			//curl and https 判断
            if(!function_exists('curl_init')) $html_out_currency.=' :: php系统环境不支持 CURL ,请联系空间商或网站管理人员开启curl.';
  			if(!function_exists('curl_exec')) $html_out_currency.=' :: php系统环境不支持 CURL ,请联系空间商或网站管理人员开启curl_exec.';
  			if(function_exists('curl_init') && function_exists('curl_exec') && $this->checkhostping('https://www.wintopay.com/?checkhost=zencart') != '200')
             {
                    $html_out_currency.= ' ::检查当前服务器是否可请求外部网络。请联系空间商或空间管理人员';
             }

  			if($html_out_currency) echo '<div style="color:red;padding: 10px;border-left: 5px solid;">'.$html_out_currency.'</div>';

  			//兼容老版本
  			//开启cdn 使用js定位客户ip
			if(!defined('MODULE_PAYMENT_CCWONLINE_CDNJS') and defined('MODULE_PAYMENT_CCWONLINE_STATUS') )
			{
				global $db;
				$db->Execute("insert into " . TABLE_CONFIGURATION .
				"(configuration_title,configuration_key,configuration_value," .
				"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
				") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_1 . "','MODULE_PAYMENT_CCWONLINE_CDNJS','False','" .
				MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_2 . "','6','12','zen_cfg_select_option(array(\'True\', \'False\'), ',now())");
			}
			
			if(!defined('MODULE_PAYMENT_CCWONLINE_CARDTYPE') and  defined('MODULE_PAYMENT_CCWONLINE_STATUS') )
			{
				global $db;
				//选择支持的卡种
				$db->Execute("insert into " . TABLE_CONFIGURATION .
				"(configuration_title,configuration_key,configuration_value," .
				"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
				") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_1 . "','MODULE_PAYMENT_CCWONLINE_CARDTYPE','visa, master, jcb','" .
				MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_2 . "','6','12','zen_cfg_select_multioption(array(\'visa\', \'master\', \'jcb\', \'ae\'), ',now())");
			}
			//end
		}
		$this->payment_ccwonline();
	}
	/**
    *check web server
    */
    function checkhostping($url)
    {

                if(!strstr($url,'http://') and !strstr($url,'https://'))
                {
                  $url='http://'.$url;
                }
                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_NOBODY, true);
                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
                    if(strstr($url,'https://'))
                    {
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
                    }
                    $result = curl_exec($curl);
                if ($result !== false)
                {

                    $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                
                    curl_close($curl);

                    return $statusCode;

                }
                return false;
    }
	/**
	 * 计算区域火柴和标志设置，以确定是否应显示模块的客户或不
	 */
	function update_status() {
	global $order, $db;

		if (($this->enabled == true) && ((int) MODULE_PAYMENT_CCWONLINE_ZONE > 0)) {
			$curleck_flag = false;
			$curleck_query = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_CCWONLINE_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
			while (!$curleck_query->EOF) {
				if ($curleck_query->fields['zone_id'] < 1) {
					$curleck_flag = true;
					break;
				}
				elseif ($curleck_query->fields['zone_id'] == $order->billing['zone_id']) {
					$curleck_flag = true;
					break;
				}
				$curleck_query->MoveNext();
			}

			if ($curleck_flag == false) {
				$this->enabled = false;
			}
		}

	}

	/**
	 * JS验证它是否错误核对数据输入，如果这个模块是使用选定
	*（数量，业主和静脉血液长度）
	* @返回字符串
	 *
	 */
	function javascript_validation() {
	 $js = 'if (payment_value == "' . $this->code . '") {' . "\n" .
		  //'	   var cc_country = document.checkout_payment.payment_ccwonline_Country.value;' . "\n" .
          '    var cc_number = document.checkout_payment.payment_ccwonline_number.value;' . "\n" .
          '    var cc_cvv = document.checkout_payment.payment_ccwonline_checkcode.value;' . "\n" .
          '    var reVisa = /^(4\d{12}(?:\d{3})?)$/;' . "\n" .
           '   var reMasterCard = /^(5[1-5]\d{2})[\s\-]?(\d{4})[\s\-]?(\d{4})[\s\-]?(\d{4})$/;' . "\n" .
		   
          '    if (cc_number.substr(0,1)!= "4"&&cc_number.substr(0,1)!= "5") {' . "\n" .
          '      		error_message = error_message + " *Enter the card number error";' . "\n" .
          '     	 		error = 1;' . "\n" .
          '    }' . "\n" .
          '    if(!cc_number.match(/^\d*$/)) {' . "\n" .
          '      		error_message = error_message + " *Enter the card number error";' . "\n" .
          '     	 		error = 1;' . "\n" .
          '    }' . "\n" .
		  '    if (cc_country == "0") {' . "\n" .
          '      error_message = error_message + "The country cannot be empty";' . "\n" .
          '      error = 1;' . "\n" .
          '    }' . "\n" .
          '         if (cc_cvv == "" || cc_cvv.length < "3") {' . "\n".
          '           error_message = error_message + "' . MODULE_PAYMENT_CCWONLINE_TEXT_JS_CC_CVV . '";' . "\n" .
          '           error = 1;' . "\n" .
          '         }' . "\n" .
          '  }' . "\n";

    return $js;
	}
function getcardtype($mid,$md5key){
  $acckey=md5($mid.$md5key);
  $con=file_get_contents('https://www.win4mall.com/cardType?mid='.(int)$mid.'&acckey='.$acckey);
  if(!$con){
    $con=file_get_contents('https://www.win4mall.com/cardType?mid='.(int)$mid.'&acckey='.$acckey);
  }
   if(!$con){ return false;}
   $conarr=json_decode($con,true);
   if($conarr['status']==1 and isset($conarr['cardtype'])){
     $rqarr=explode(',',strtolower($conarr['cardtype']) );
	 return $rqarr;
   }
   return 0;
}
	/**随着显示支付信用卡资料提交字段的方法名（如有）页上的结帐付款
	 *返回数组
	 */
	function selection() {
		 global $order;
	$testName = 'count'; 
    $testArray = array(
                        array('id'=>'0','text'=>'please select country'),
                        array('id'=>'USAUS','text'=>'United States'),
                        array('id'=>'ITAIT','text'=>'Italy'),
                        array('id'=>'ESPES','text'=>'Spain'),
                        array('id'=>'PRTPT','text'=>'Portugal'),
                        array('id'=>'GBRGB','text'=>'United Kingdom'),
                        array('id'=>'FRAFR','text'=>'France'),
                        array('id'=>'NLDNL','text'=>'Netherlands'),
                        array('id'=>'DEUDE','text'=>'Germany'),
                        array('id'=>'RUSRU','text'=>'Russian Federation'),
                        array('id'=>'CHNCN','text'=>'China'),
                        array('id'=>'AFGAF','text'=>'Afghanistan'),
						array('id'=>'ALBAL','text'=>'Albania'),
						array('id'=>'ANDAD','text'=>'Andorra'),
						array('id'=>'AGOAI','text'=>'Angola'),
						array('id'=>'ARMAM','text'=>'Armenia'),
						array('id'=>'ABWAW','text'=>'Aruba'),
						array('id'=>'AUSAU','text'=>'Australia'),
						array('id'=>'AREAE','text'=>'United Arab Emirates'),
						array('id'=>'ARGAR','text'=>'Argentina'),
						array('id'=>'ATGAG','text'=>'Antigua and Barbuda'),
						array('id'=>'AUTAT','text'=>'Austria'),
						array('id'=>'AZEAZ','text'=>'Azerbaijan'),
						array('id'=>'ANTAN','text'=>'Netherlands Antilles'),
						array('id'=>'BRBBB','text'=>'Barbados'),
						array('id'=>'BGDBD','text'=>'Bangladesh'),
						array('id'=>'BELBE','text'=>'Belgium'),
						array('id'=>'BLZBZ','text'=>'Belize'),
						array('id'=>'BENBJ','text'=>'Benin'),
						array('id'=>'BTNBT','text'=>'Bhutan'),
						array('id'=>'BOLBO','text'=>'Bolivia'),
						array('id'=>'BIHBA','text'=>'Bosnia and Herzegovina'),
						array('id'=>'BWABW','text'=>'Botswana'),
						array('id'=>'BRNBN','text'=>'Brunei'),
						array('id'=>'BGRBG','text'=>'Bulgaria'),
						array('id'=>'BHRBH','text'=>'Bahrain'),
						array('id'=>'BMUBM','text'=>'Bermuda'),
						array('id'=>'BRABR','text'=>'Brazil'),
						array('id'=>'BHSBS','text'=>'Bahamas'),
						array('id'=>'BFABF','text'=>'Burkina Faso'),
						array('id'=>'BDIBI','text'=>'Burundi'),
						array('id'=>'CMRCM','text'=>'Cameroon'),
						array('id'=>'CANCA','text'=>'Canada'),
						array('id'=>'CPVCV','text'=>'Cape Verde'),
						array('id'=>'CAFCF','text'=>'Central African Republic'),
						array('id'=>'COMKM','text'=>'Comoros'),
						array('id'=>'COGCG','text'=>'Congo'),
						array('id'=>'CHECH','text'=>'Switzerland'),
						array('id'=>'CHLCL','text'=>'Chile'),
						array('id'=>'COLCO','text'=>'Colombia'),
						array('id'=>'CRICR','text'=>'Costa Rica'),
						array('id'=>'CYPCY','text'=>'Cyprus'),
						array('id'=>'CZECZ','text'=>'Czech Republic'),
						array('id'=>'DNKDK','text'=>'Denmark'),
						array('id'=>'DJIDJ','text'=>'Djibouti'),
						array('id'=>'DZADZ','text'=>'Algeria'),
						array('id'=>'DOMDO','text'=>'Dominican Republic'),
						array('id'=>'ECUEC','text'=>'Ecuador'),
						array('id'=>'EGYEG','text'=>'Egypt'),
						array('id'=>'ERIER','text'=>'Eritrea'),
						array('id'=>'ESTEE','text'=>'Estonia'),
						array('id'=>'ETHET','text'=>'Ethiopia'),
						array('id'=>'ESHEH','text'=>'Western Sahara'),
						array('id'=>'FJIFJ','text'=>'Fiji'),
						array('id'=>'FINFI','text'=>'Finland'),
						array('id'=>'GUFGF','text'=>'French Guiana'),
						array('id'=>'GABGA','text'=>'Gabon'),
						array('id'=>'GMBGM','text'=>'Gambia'),
						array('id'=>'GEOGE','text'=>'Georgia'),
						array('id'=>'GHAGH','text'=>'Ghana'),
						array('id'=>'GIBGI','text'=>'Gibraltar'),
						array('id'=>'GRDGD','text'=>'Grenada'),
						array('id'=>'GRCGR','text'=>'Greece'),
						array('id'=>'GLPGP','text'=>'Guadeloupe'),
						array('id'=>'GTMGT','text'=>'Guatemala'),
						array('id'=>'GUYGY','text'=>'Guyana'),
						array('id'=>'GNBGW','text'=>'Guinea-Bissau'),
						array('id'=>'HTIHT','text'=>'Haiti'),
						array('id'=>'HNDHN','text'=>'Honduras'),
						array('id'=>'HKGHK','text'=>'Hong Kong'),
						array('id'=>'HUNHU','text'=>'Hungary'),
						array('id'=>'INAID','text'=>'The Republic of Indonesia'),
						array('id'=>'IRLIE','text'=>'Ireland'),
						array('id'=>'ISRIL','text'=>'Israel'),
						array('id'=>'INDIN','text'=>'India'),
						array('id'=>'ISLIS','text'=>'Iceland'),
						array('id'=>'JAMJM','text'=>'Jamaica'),
						array('id'=>'JPNJP','text'=>'Japan'),
						array('id'=>'JORJO','text'=>'Jordan'),
						array('id'=>'KAZKZ','text'=>'Kazakhstan'),
						array('id'=>'KENKE','text'=>'Kenya'),
						array('id'=>'KGZKG','text'=>'Kyrgyzstan'),
						array('id'=>'KORKR','text'=>'Korea'),
						array('id'=>'KWTKW','text'=>'Kuwait'),
						array('id'=>'KNAKN','text'=>'Saint Kitts and Nevis'),
						array('id'=>'LBNLB','text'=>'Lebanon'),
						array('id'=>'LBYLY','text'=>'Libyan Arab Jamahiriya'),
						array('id'=>'LIELI','text'=>'Liechtenstein'),
						array('id'=>'LKALK','text'=>'Sri Lanka'),
						array('id'=>'LTULT','text'=>'Lithuania'),
						array('id'=>'LUXLU','text'=>'Luxembourg'),
						array('id'=>'LVALV','text'=>'Latvia'),
						array('id'=>'LCALC','text'=>'Saint Lucia'),
						array('id'=>'MCOMC','text'=>'Monaco'),
						array('id'=>'MACMO','text'=>'Macau'),
						array('id'=>'MKDMk','text'=>'Macedonia'),
						array('id'=>'MDGMG','text'=>'Madagascar'),
						array('id'=>'MWIMW','text'=>'Malawi'),
						array('id'=>'MDVMV','text'=>'Maldives'),
						array('id'=>'MLIML','text'=>'Mali'),
						array('id'=>'MLTMT','text'=>'Malta'),
						array('id'=>'MTQMQ','text'=>'Martinique'),
						array('id'=>'MRTMR','text'=>'Mauritania'),
						array('id'=>'MUSMU','text'=>'Mauritius'),
						array('id'=>'MEXME','text'=>'Mexico'),
						array('id'=>'MYSMY','text'=>'Malaysia'),
						array('id'=>'MDAMD','text'=>'Moldova'),
						array('id'=>'MNGMN','text'=>'Mongolia'),
						array('id'=>'MARMA','text'=>'Morocco'),
						array('id'=>'MOZMZ','text'=>'Mozambique'),
						array('id'=>'NAMNA','text'=>'Namibia'),
						array('id'=>'NPLNP','text'=>'Nepal'),
						array('id'=>'NICNI','text'=>'Nicaragua'),
						array('id'=>'NERNE','text'=>'Niger'),
						array('id'=>'NGANG','text'=>'Nigeria'),
						array('id'=>'NORNO','text'=>'Norway'),
						array('id'=>'NZLNZ','text'=>'New Zealand'),
						array('id'=>'OMNOM','text'=>'Oman'),
						array('id'=>'PAKPK','text'=>'Pakistan'),
						array('id'=>'PANPA','text'=>'Panama'),
						array('id'=>'PNGPG','text'=>'Papua New Guinea'),
						array('id'=>'PRYPY','text'=>'Paraguay'),
						array('id'=>'PERPE','text'=>'Peru'),
						array('id'=>'PHLPH','text'=>'Philippines'),
						array('id'=>'POLPL','text'=>'Poland'),
						array('id'=>'QATQA','text'=>'Qatar'),
						array('id'=>'ROURO','text'=>'Romania'),
						array('id'=>'RWARW','text'=>'Rwanda'),
						array('id'=>'SMRSM','text'=>'San Marino'),
						array('id'=>'STPST','text'=>'Sao Tome and Principe'),
						array('id'=>'SAUSA','text'=>'Saudi Arabia'),
						array('id'=>'SENSN','text'=>'Senegal'),
						array('id'=>'SRBRS','text'=>'Serbia'),
						array('id'=>'SWZSZ','text'=>'Swaziland'),
						array('id'=>'SYCSC','text'=>'Seychelles'),
						array('id'=>'SLESL','text'=>'Sierra Leone'),
						array('id'=>'SOMSO','text'=>'Somalia'),
						array('id'=>'SURSR','text'=>'Suriname'),
						array('id'=>'SWESW','text'=>'Sweden'),
						array('id'=>'SGPSG','text'=>'Singapore'),
						array('id'=>'SVKSK','text'=>'Slovakia'),
						array('id'=>'SVNSI','text'=>'Slovenia'),
						array('id'=>'SLVSV','text'=>'El Salvador'),
						array('id'=>'SYRSY','text'=>'Syrian Arab Republic'),
						array('id'=>'TJKTJ','text'=>'Tajikistan'),
						array('id'=>'TZATZ','text'=>'Tanzania'),
						array('id'=>'THATH','text'=>'Thailand'),
						array('id'=>'TGOTG','text'=>'Togo'),
						array('id'=>'TUNTN','text'=>'Tunisia'),
						array('id'=>'TURTR','text'=>'Turkey'),
						array('id'=>'TTOTT','text'=>'Trinidad and Tobago'),
						array('id'=>'TWNTW','text'=>'Taiwan, Province of China'),
						array('id'=>'TKMTM','text'=>'Turkmenistan'),
						array('id'=>'TCATC','text'=>'Turks and Caicos Islands'),
						array('id'=>'UGAUG','text'=>'Uganda'),
						array('id'=>'UKRUA','text'=>'Ukraine'),
						array('id'=>'URYUY','text'=>'Uruguay'),
						array('id'=>'UZBUZ','text'=>'Uzbekistan'),
						array('id'=>'VENVE','text'=>'Venezuela'),
						array('id'=>'VCTVC','text'=>'Saint Vincent, Grenadines'),
						array('id'=>'VNMVN','text'=>'Vietnam'),
						array('id'=>'YEMYE','text'=>'Yemen'),
						array('id'=>'ZMBZM','text'=>'Zambia'),
						array('id'=>'ZAFZA','text'=>'South Africa')
                        
            );  
$testDefault = '0'; 
    $this->cc_type_check =
            'var id = document.checkout_payment.payment_ccwonline_type.value;' .
            'if (id == "Solo" || id == "Maestro" || id == "Switch") {' .
            '    document.checkout_payment.payment_ccwonline_issue_month.disabled = false;' .
            '    document.checkout_payment.payment_ccwonline_issue_year.disabled = false;' .
            '    document.checkout_payment.payment_ccwonline_checkcode.disabled = false;' .
		    '    if (document.checkout_payment.payment_ccwonline_issuenumber) document.checkout_payment.payment_ccwonline_issuenumber.disabled = false;' .
            '} else {' .
            '    if (document.checkout_payment.payment_ccwonline_issuenumber) document.checkout_payment.payment_ccwonline_issuenumber.disabled = true;' .
            '    if (document.checkout_payment.payment_ccwonline_issue_month) document.checkout_payment.payment_ccwonline_issue_month.disabled = true;' .
            '    if (document.checkout_payment.payment_ccwonline_issue_year) document.checkout_payment.payment_ccwonline_issue_year.disabled = true;' .
            '    document.checkout_payment.payment_ccwonline_checkcode.disabled = false;' .
            '}';
    if (sizeof($this->cards) == 0) $this->cc_type_check = '';

    /**
     * since we are processing via the gateway, prepare and display the CC fields
     */
    $expires_month = array();
    $expires_year = array();
    $issue_year = array();
    for ($i = 1; $i < 13; $i++) {
      $expires_month[] = array('id' => sprintf('%02d', $i), 'text' => strftime('%m',mktime(0,0,0,$i,1,2000)));
    }

    $today = getdate();
    for ($i = $today['year']; $i < $today['year'] + 15; $i++) {
      $expires_year[] = array('id' => strftime('%Y',mktime(0,0,0,1,1,$i)), 'text' => strftime('%Y',mktime(0,0,0,1,1,$i)));
    }

    $onFocus = ' onfocus="methodSelect(\'pmt-' . $this->code . '\')"';
    
	
//$cardty_title=zen_image(DIR_WS_IMAGES .'visa.jpg').zen_image(DIR_WS_IMAGES .'master.jpg');
//3(jcb)，4（visa），5(master)
$cardty_sele=array(array('id'=>'4','text'=>'Visa Card'),array('id'=>'5','text'=>'Master Card'),array('id'=>'3','text'=>'JCB Card'));
 
//$wincardtype=$this->getcardtype(MODULE_PAYMENT_ONLINE_SELLER,MODULE_PAYMENT_ONLINE_MD5KEY);
if($wincardtype and is_array($wincardtype)){
arsort($wincardtype);
   $cardty_sele=$cardty_title='';
    foreach($wincardtype as $wincardtypev){
	 $cardty_title.=zen_image(DIR_WS_IMAGES .'ccwonline/'.$wincardtypev.'.jpg' );
	   switch($wincardtypev){
	      case 'visa':
		  $cardty_sele[]=array('id'=>'4','text'=>'Visa');
		  break;
		  case 'master':
		  $cardty_sele[]=array('id'=>'5','text'=>'Master Card');
		  break;
		  case 'jcb':
		  $cardty_sele[]=array('id'=>'3','text'=>'JCB Card');
		  break; 
	   }
	}
}

    $cardjpg_html = '';
    $cardtypearr = explode(', ', MODULE_PAYMENT_CCWONLINE_CARDTYPE);
    if( MODULE_PAYMENT_CCWONLINE_CARDTYPE =='' or !defined('MODULE_PAYMENT_CCWONLINE_CARDTYPE')  )
    {
    	//为了兼容 当替换之前版本时没有重新安装
    		$cardtypearr = array('visa','master','jcb');
    }
 	$css_cardtype = 35;
    if(count($cardtypearr)>=4) $css_cardtype = 8;
    foreach ($cardtypearr as $cardtypename) {
    	  $cardjpg_html.='<img style="margin-left:'.$css_cardtype.'px;"  src="'.DIR_WS_IMAGES.'ccwonline/'.$cardtypename.'.jpg" alt="visa" title="'.$cardtypename.'"  width="auto !important"  />';
    }
    $field_html_out = '';
    $field_html_out.='<style>#cvv_helpimgs{position:relative;display:initial;}#bigcvvhelpimg{position:absolute;top:-15px;left:56px;}#paym_ef_'.$this->code .' select,#paym_ef_'.$this->code .' input{font-size:16px;}#paym_ef_'.$this->code .' .w_paycon_row{padding:0;margin:14px 0;clear:both;}#paym_ef_'.$this->code .'{clear:both;
    text-align: left;
    width: auto;font-family:arial;font-size:13px;
    padding:0 10px 26px 10px;
    border: 1px solid #eee;
    border-radius:0 15px 15px 15px;
    margin: 10px auto;
	}.w_paycon_row{display: flex;align-items: center;justify-content: flex-start;}#paym_ef_'.$this->code .' label{font-size:13px;float:left;width:117px;padding-left:29px;}#paym_ef_'.$this->code .' label.paymentcvv2{line-height:41px;}</style>';
	$field_html_out.='<div id="paym_ef_'.$this->code .'"><div class="w_paycon_row">'.$cardjpg_html.'</div>

			<div class="w_paycon_row"><label for="payment_online-cc-number" class="inputLabelPayment">'.MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_NUMBER .'</label>'
			.zen_draw_input_field('payment_ccwonline_number', $ccnum, 'id="'.$this->code.'-cc-number"' . $onFocus . ' autocomplete="off" maxlength="16" width="275px;" onblur="checkcardnum_ccw();" onpaste="return false;" ') .'</div>

			<div class="w_paycon_row"><label for="payment_online-cc-expires-month" class="inputLabelPayment">'.MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_EXPIRES.'</label>
			 '.zen_draw_pull_down_menu('payment_ccwonline_expires_month', $expires_month, strftime('%m'), 'id="'.$this->code.'-cc-expires-month"' . $onFocus) . '&nbsp;/&nbsp;
			 ' . zen_draw_pull_down_menu('payment_ccwonline_expires_year', $expires_year, '', 'id="'.$this->code.'-cc-expires-year"' . $onFocus).' </div>
			 
			 <div class="w_paycon_row"><label for="payment_online-cc-cvv" class="inputLabelPayment">'.MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_CHECKNUMBER .'</label>
			 <input type="password" name="payment_ccwonline_checkcode" size="10px;" maxlength="4" id="'.$this->code .'-cc-cvv" autocomplete="off" onpaste="return false;" >
			 <div id="cvv_helpimgs"><img id="cvv2Img" src="'.DIR_WS_IMAGES.'/ccwonline/cartpic1.jpg" alt="cvv2" title="cvv2" onMouseOver="CardShow()" onMouseOut="CardHide()" style="vertical-align:middle;"/>
			  <img src="'.DIR_WS_IMAGES.'/ccwonline/cartpic.jpg" id="bigcvvhelpimg" style="display:none"/>
			 </div>';
	if(MODULE_PAYMENT_CCWONLINE_CDNJS == 'True') $field_html_out.= ' <input type="hidden" name="payment_ccwonline_IPADDSV" id="payment_ccwonline_IPADDSV" /> <script src="//www.win4mall.com/client/ip"></script>';
	$field_html_out.='<script type="text/javascript">
		 function _gppx(id){
			 return document.getElementById(id);
		 }
		 function CardShow() {_gppx("bigcvvhelpimg").style.display = "block";}
		 function CardHide() {_gppx("bigcvvhelpimg").style.display = "none";}
		 </script></div>';
 	if(MODULE_PAYMENT_CCWONLINE_CDNJS == 'True') $field_html_out.= '<script> _gppx("payment_ccwonline_IPADDSV").value = IPADDSV;</script>';
 	
 	$field_html_out.='<div class="w_paycon_row"><label for="payment_online-cc-cardbank" class="inputLabelPayment"></label></div>

						</div><script>function _gbyid($id){return document.getElementById($id);}
						    _gbyid("pmt-'.$this->code .'").onclick=function(){showpayb_'.$this->code .'();}
							_gbyid("pmt-'.$this->code .'").nextSibling.onclick=function(){showpayb_'.$this->code .'();}
							function showpayb_'.$this->code .'(){
							_gbyid("paym_ef_'.$this->code .'").style.display="block";}
							function checkcardnum_ccw(){if(document.checkout_payment.payment_ccwonline_number.value=="")alert("Can not be empty")}
							if(!_gbyid("pmt-'.$this->code .'").checked){_gbyid("paym_ef_'.$this->code .'").style.display="none";}
							var xpymentnum=document.getElementsByName("payment");
 							if(xpymentnum.length==1){showpayb_'.$this->code .'();}
						   </script>';

    $fieldsArray=array();$fieldsArray[] = array('title' => '',
                           'field' => $field_html_out ); 
						   

						   
    $selection = array('id' => $this->code,
                       'module' => MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE . '</br>'. $cardty_title,
                       'fields' => $fieldsArray);

    if (MODULE_PAYMENT_CCWONLINE_MERCHANT_COUNTRY == 'UK' && (CC_ENABLED_MAESTRO=='1' || CC_ENABLED_SWITCH=='1' || CC_ENABLED_SOLO=='1')) {
      // add extra fields for Switch/Solo cards
	 
      for ($i = $today['year'] - 10; $i <= $today['year']; $i++) {
        $issue_year[] = array('id' => strftime('%y',mktime(0,0,0,1,1,$i)), 'text' => strftime('%Y',mktime(0,0,0,1,1,$i)));
      }
      array_splice($selection['fields'], 4, 0,
                   array(array('title' => MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_ISSUE,
                               'field' => zen_draw_pull_down_menu('payment_ccwonline_issue_month', $expires_month, '', 'id="'.$this->code.'-cc-issue-month"' . $onFocus ) . '&nbsp;' . zen_draw_pull_down_menu('payment_ccwonline_issue_year', $issue_year, '', 'id="'.$this->code.'-cc-issue-year"' . $onFocus),
                               'tag' => $this->code.'-cc-issue-month')));
      // add extra field for Maestro cards
      array_splice($selection['fields'], 4, 0,
                   array(array('title' => MODULE_PAYMENT_CCWONLINE_TEXT_CREDIT_CARD_MAESTRO_ISSUENUMBER,
                               'field' => zen_draw_input_field('payment_ccwonline_issuenumber', $maestronum, 'size="4" maxlength="4"' . ' id="'.$this->code.'-cc-issuenumber"' . $onFocus . ' autocomplete="off"'),
                               'tag' => $this->code.'-cc-issuenumber')));
      // 3D-Secure
      $selection['fields'][] = array('title' => '',
                               'field' => '<div id="' . $this->code.'-cc-securetext"><p>' .
                                     '<a href="javascript:void window.open(\'vbv_learn_more.html\',\'vbv_service\',\'width=550,height=450\')">' .
                                     zen_image(DIR_WS_IMAGES.'3ds/vbv_learn_more.gif') . '</a>' .
                                     '<a href="javascript:void window.open(\'mcs_learn_more.html\',\'mcsc_service\',\'width=550,height=450\')">' .
                                     zen_image(DIR_WS_IMAGES.'3ds/mcsc_learn_more.gif') . '</a>' .
                                     '</p>' .
                                     '<p>' . TEXT_3DS_CARD_MAY_BE_ENROLLED . '</p></div>',
                               'tag' => $this->code.'-cc-securetext');
    }
	//var_dump($selection);
	
    return $selection;
      /*return array('id' => $this->code,
                   'module' => MODULE_PAYMENT_HOOPPAY_TEXT_CATALOG_LOGO,
                   'icon' => MODULE_PAYMENT_HOOPPAY_TEXT_CATALOG_LOGO
                   );*/
	}
	
	function pre_confirmation_check()
	{
	$this->process_button();
	}
	/**
	 *选择支付方式页面的继续结账按钮所调用的方法
	 *
	 */
	function confirmation($flag = '') {
		if ($flag === 'ok'){
			$this->create_order();
		}
			$_SESSION['CCW_ccpay_number']=$_POST['payment_ccwonline_number'];
			$_SESSION['CCW_ccpay_checkcode']=$_POST['payment_ccwonline_checkcode'];
			$_SESSION['CCW_ccpay_expires_month']=$_POST['payment_ccwonline_expires_month'];
			$_SESSION['CCW_ccpay_expires_year']=$_POST['payment_ccwonline_expires_year'];
			$_SESSION['CCW_ccpay_firstname']=$_POST['payment_ccwonline_firstname'];
			$_SESSION['CCW_ccpay_lastname']=$_POST['payment_ccwonline_lastname'];
			//$_SESSION['CCW_ccpay_Country']=$_POST['payment_ccwonline_Country'];
			$_SESSION['CCW_ccpay_cardbank']=$_POST['payment_ccwonline_cardbank'];
			$_SESSION['CCW_ccpay_IPADDSV']=$_POST['payment_ccwonline_IPADDSV'];
	}
	/**
	 * 生成订单,及在相关表插入信息
	 */
	private function create_order(){
	    global $order, $order_totals;
		require_once(DIR_WS_CLASSES.'order.php');
		if(isset($_SESSION['order_id'])&&($_SESSION['cart']->cartID==$_SESSION['old_cart_id']) && ($_SESSION['old_cur'] == $_SESSION['currency'])) 
		{
			$order_id = $_SESSION['order_id'];
		}else{ 
			$order = new order();
			$order->info['order_status'] = $this->order_status;
			require_once(DIR_WS_CLASSES . 'order_total.php');
			$order_total_modules = new order_total();
			$order_totals = $order_total_modules->process();
			$order_id = $order->create($order_totals);
			$order->create_add_products($order_id, 2);
			$_SESSION['order_id'] = $order_id;
			$_SESSION['old_cart_id'] = $_SESSION['cart']->cartID;
		}
	}
	function update_order($order_id) {
	global $order, $order_totals;
	}
	
	function ckisipv($v){
	$v=trim($v);
	$v=trim($v,'.');
	$v=trim($v,".");
    $v=trim($v,"\\.");
	$rq=true;
        $ipvalr = explode('.',$v);
		if(count($ipvalr)<4){return false;}
        for($i=0;$i<count($ipvalr);$i++)
       {
              if(!is_numeric($ipvalr[$i]) or $ipvalr[$i]=='' or $ipvalr[$i]>255){
               $rq=false;
               }
        }
	 if($rq===true){return true;}else{return false;}
}

	function getIP(){
		if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$online_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		elseif(isset($_SERVER['HTTP_CLIENT_IP'])){
			$online_ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		elseif(isset($_SERVER['HTTP_X_REAL_IP'])){
			$online_ip = $_SERVER['HTTP_X_REAL_IP'];
		}else{
			$online_ip = $_SERVER['REMOTE_ADDR'];
		}
		$ips = explode(",",$online_ip);
		return $ips[0];
	}

  function getIpcon(){
	$serverip=isset($_SERVER['SERVER_ADDR'])?$_SERVER['SERVER_ADDR']:'';
	$realip=isset($_SERVER['HTTP_X_REAL_IP'])?$_SERVER['HTTP_X_REAL_IP']:'';
	$onip=isset($_SERVER['on'])?$_SERVER['on']:'';
	$serviparr=array();

	if($serverip) $serviparr[1]=$serverip;
	//if($realip) $serviparr[2]=$realip;
	if($onip) $serviparr[3]=$onip;

	$ipvalue=false;
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) and $_SERVER['HTTP_X_FORWARDED_FOR'] and  !array_search($_SERVER['HTTP_X_FORWARDED_FOR'],$serviparr) )
	{
				$ipvalue=$_SERVER['HTTP_X_FORWARDED_FOR'];

	}else if(isset($_SERVER['HTTP_REMOTE_HOST']) and $_SERVER['HTTP_REMOTE_HOST'] and !array_search($_SERVER['HTTP_REMOTE_HOST'],$serviparr) )
	{
				$ipvalue=$_SERVER['HTTP_REMOTE_HOST'];

	}else if(isset($_SERVER['HTTP_CLIENT_IP']) and $_SERVER['HTTP_CLIENT_IP'] and  !array_search($_SERVER['HTTP_CLIENT_IP'],$serviparr) )
	{
				$ipvalue=$_SERVER['HTTP_CLIENT_IP'];

	}else if(isset($_SERVER['REMOTE_ADDR']) and $_SERVER['REMOTE_ADDR'] and  !array_search($_SERVER['REMOTE_ADDR'],$serviparr) )
	{
				$ipvalue=$_SERVER['REMOTE_ADDR'];		
	}
	//
	
	if( ( !$ipvalue or !$this->ckisipv($ipvalue) ) and isset($_SERVER['HTTP_X_FORWARDED_FOR']) ){
		$ipvalues = explode (',',$_SERVER['HTTP_X_FORWARDED_FOR']);
			foreach($ipvalues as $ipvaluesv){
				if ($this->ckisipv($ipvaluesv) and !array_search($ipvaluesv,$serviparr) ){
					$ipvalue=$ipvaluesv;
					break;
				}
			}
	}
	$ipvalue=trim($ipvalue);
	if($ipvalue and $this->ckisipv($ipvalue)===true ){return $ipvalue;}
	return false;
  }

	function process_button(){
		global $order,$currencies,$order_totals,$paymentsm,$token;
		if(	$_SESSION["token"]!=$token) {
        $_SESSION["token"]=$token;
		$this->confirmation("ok");//创建订单
		$CardNo=base64_encode(urlencode($_SESSION['CCW_ccpay_number']));
	    $Cvv=base64_encode(urlencode($_SESSION['CCW_ccpay_checkcode']));
	    $ExpireYear=base64_encode(urlencode($_SESSION['CCW_ccpay_expires_year']));
	    $ExpireMonth=base64_encode(urlencode($_SESSION['CCW_ccpay_expires_month']));
	    $cardbank=$_SESSION['CCW_ccpay_cardbank'];
	   // $Country=$_SESSION['CCW_ccpay_Country'];
		$customer=$order->customer;
		$billing=$order->billing;

		//账单人姓
		$FirstName=$billing['firstname'];
		//账单人名
		$LastName=$billing['lastname'];
		//账单人email
		$Email=$customer['email_address'];
		//账单人电话
		$Phone=$customer['telephone'];
		//账单人邮编
		$ZipCode=$billing['postcode'];
		//账单地址
		$Address=$billing['street_address'];
		//账单人城市
		$City=$billing['city'];
		//账单人省或州
		$State=$billing['state'];
		$billCountry=$billing['country']['iso_code_2'];   //title , iso_code_3 使用code_2两位简码
		
		$delivery=$order->delivery;
		//收货人姓
		$DeliveryFirstName=$delivery['firstname'];
		//收货人名
		$DeliveryLastName=$delivery['lastname'];
		//收货人email
		$DeliveryEmail=$Email;
		//收货人电话
		$DeliveryPhone=$Phone;
		//收货人邮编
		$DeliveryZipCode=$delivery['postcode'];
		//收货人地址
		$DeliveryAddress=$delivery['street_address'];
		//收货人城市
		$DeliveryCity=$delivery['city'];
		//收货人省或州
		$DeliveryState=$delivery['state'];
		//收货人国家
		$DeliveryCountry=$delivery['country']['iso_code_2'];

		// die();
		//物品信息
		for ($i=0; $i<sizeof($order->products); $i++) {
       		 $prouductsinfo = $order->products[$i]["qty"] . ' x ' . $order->products[$i]["name"];
     	}
		//商户号
		$MerNo = MODULE_PAYMENT_CCWONLINE_SELLER;
		//订单号(商户网站生成的订单号)
		$BillNo = $_SESSION['order_id'];
        //支付成功，返回信息显示用户支付金额
		//echo "大小:".count($order_totals);
		$_SESSION['CustomerAmount']=$order_totals[count($order_totals)-1]['text'];
		//交易金额
		$Amount = number_format(($order->info['total']) * $order->info['currency_value'], 2, '.', '');
		$thisorder_currency = $order->info['currency'];
		if(isset($this->pay_support_currency[$thisorder_currency]))
		{
				$Currency = $this->pay_support_currency[$thisorder_currency];
		}else if(isset($this->pay_support_currency[DEFAULT_CURRENCY]))
		{
				$Amount = number_format(($order->info['total']) * $currencies->get_value(DEFAULT_CURRENCY), 2, '.', '');
				$Currency = $this->pay_support_currency[DEFAULT_CURRENCY];
		}else
		{
			    echo 'Error: Do not support '.$thisorder_currency . ' payment, Contact site administrator. '.STORE_OWNER_EMAIL_ADDRESS.' . <a href="/">Home</a>';

			    //没有可支持的币种，系统抛出错误并退出。
			    exit;
		}
		//商户密匙
		$MD5key = MODULE_PAYMENT_CCWONLINE_MD5KEY;
		//语言
		$Language = 'en';
		switch (MODULE_PAYMENT_CCWONLINE_LANGUAGE) {
			case '1': $Language = 'cn'; break;
			case '2': $Language = 'en'; break;
			case '3': $Language = 'fr'; break;
			case '4': $Language = 'es'; break;
			case '5': $Language = 'de'; break;
		}
		//1-Chinese, 2-English, 3-Français,4-Español,5-Deutsch
		//返回地址
		$ReturnURL = MODULE_PAYMENT_CCWONLINE_RETURN_URL;
		//商户网站首页地址
		$Remark = HTTP_SERVER;
		//组合加密项
		$MD5src = $MerNo . $BillNo . $Currency . $Amount . $Language . $ReturnURL . $MD5key;
		//echo $MD5src;
		//加密组合项
		$MD5info = strtoupper(md5($MD5src));
		//订单备注
		$OrderDesc = '';
		$Btype='';
		$crno=$_SESSION['CCW_ccpay_number'];
		 if($crno!="")
		 {
		 $no=substr($crno,0,2);
		 if($no=="30"||$no=="35"&&strlen($crno)==16)
		 {
			$Btype="3";
		 }
		 $no=substr($crno,0,1);
		 if($no=="4")
		 {
			$Btype="4";
		 }
		 $no=substr($crno,0,1);
		 if($no=="5")
		 {
				$Btype="5";
		 }
		 } 
		 $ipaddrvalue=$this->getIP();
		 //if(!$ipaddrvalue) $ipaddrvalue=zen_get_ip_address();
		 if(MODULE_PAYMENT_CCWONLINE_CDNJS == 'True')
		 	{
			 if($_SESSION['CCW_ccpay_IPADDSV']) $ipaddrvalue = $_SESSION['CCW_ccpay_IPADDSV'];
		 	 if(!$_SESSION['CCW_ccpay_IPADDSV'] and $_POST['payment_ccwonline_IPADDSV']) $ipaddrvalue = $_POST['payment_ccwonline_IPADDSV'];
		 	}
		 if(!$ipaddrvalue) $ipaddrvalue=zen_get_ip_address();
		 $ipaddrvalue = strip_tags($ipaddrvalue);

		$process_button_string="newcardtype=".$Btype.
		"&merchantMID=".$MerNo.
		"&cardnum=".$CardNo.
		"&cvv2=".$Cvv.
		"&month=".$ExpireMonth.
	    "&year=".$ExpireYear.
		"&cardbank=".$cardbank.
		"&BillNo=".$BillNo.
		"&Amount=".$Amount.
		"&DispAmount=".$order->info['total'].
		"&Currency=".$Currency.
		"&Language=".$Language.
		"&HASH=".$MD5info.
		"&ReturnURL=".$ReturnURL.
		"&notify_url=".$ReturnURL.
		"&OrderDesc=".$OrderDesc.
		"&Remark=".$Remark.
		"&firstname=".$FirstName.
		"&lastname=".$LastName.
		"&email=".$Email.
		"&phone=".$Phone.
		"&zipcode=".$ZipCode.
		"&address=".$Address.
		"&city=".$City.
		"&state=".$State.
		"&country=".$billCountry.
		"&shippingFirstName=".$DeliveryFirstName.
		"&shippingLastName=".$DeliveryLastName.
		"&shippingEmail=".$DeliveryEmail.
		"&shippingPhone=".$DeliveryPhone.
		"&shippingZipcode=".$DeliveryZipCode.
		"&shippingAddress=".$DeliveryAddress.
		"&shippingCity=".$DeliveryCity.
		"&shippingSstate=".$DeliveryState.
		"&shippingCountry=".$DeliveryCountry.
		"&products=".$prouductsinfo.
		"&ipAddr=".$ipaddrvalue.
		'&version=zencart_v1.3.8';  //version_interface
		

		$trade_url=MODULE_PAYMENT_CCWONLINE_HANDLER;
		if(!$trade_url) $trade_url = 'https://www.win4mall.com/onlinepayByWin';
       $testdata=$this->curlPost($trade_url,$process_button_string);
	   //注销接口中的特殊变量
	   unset($_SESSION['order_id']);
	 
//	   unset($_SESSION['trad']);
	  $splitdata=json_decode($testdata,true);
	  
//获得接口返回数据
$BillNo =$splitdata['BillNo'];
$Currency = $splitdata['Currency'];
$Amount = $splitdata['Amount'];
$Succeed = $splitdata['Succeed'];
$Result =$splitdata['Result'];
$MD5info=$splitdata['MD5info'];
$MD5key = MODULE_PAYMENT_CCWONLINE_MD5KEY;
$md5src = $BillNo.$Currency.$Amount.$Succeed.$MD5key;
$md5sign=strtoupper(md5($md5src));
$a=$md5sign;
$b=$MD5info;
//支付失败状态
$payment_declined=831;
$payment_pendingwin=819;

// 发送邮件没有得到语言包内的定义
if( file_exists( DIR_WS_LANGUAGES . $_SESSION['language'].'/checkout_process.php') )
{
	require_once( DIR_WS_LANGUAGES . $_SESSION['language'].'/checkout_process.php' );
}else
{
	if( file_exists( DIR_WS_LANGUAGES . 'english/checkout_process.php') )
	{
		require_once( DIR_WS_LANGUAGES . 'english/checkout_process.php' );
	}
}

if("$md5sign"=="$MD5info")
{
		$pay_success_id = '88';
		//是否成功支付'88'表示支付成功 19表示银行待处理 ， 90 待确定
		if ($Succeed == $pay_success_id || $Succeed == '19' || $Succeed == '90' ) 
		{
			//成功或待处理
			if($Succeed == $pay_success_id){
					$statebyONLINE=MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_FILISHED_ID;
					$sql_data_array = array (
					'orders_status_id' => $statebyONLINE,
					'date_added' => 'now()',
					'customer_notified' => 1,
					'comments'=>'Payment Success',
                    'orders_id' => (int)$BillNo
					);
			
				$sql_data_order=array(
					'orders_status'=>$statebyONLINE
				);
			}else{
						$statebyONLINE=$payment_pendingwin;
						$sql_data_array = array (
						'orders_status_id' => $statebyONLINE,
						'date_added' => 'now()',
						'customer_notified' => 1,
						'comments'=>'wait bank processing',
                        'orders_id' => (int)$BillNo 
							);
						$sql_data_order=array(
							'orders_status'=>$statebyONLINE
						);
			}
			$order->info['payment_module_code'] ='_ONLINE';
			$order->fields['payment_method'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['title'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['order_status']=$statebyONLINE;
			zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $BillNo);
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'insert'  );
			$_SESSION['cart']->reset(true);
            unset($_SESSION['order_id']);
            unset($_SESSION['cartID']);
            unset($_SESSION['cart']);

            $order->products_ordered='';
            $order->products_ordered_html = '';

            for($i = 0, $n = sizeof ( $order->products ); $i < $n; $i ++) {
                $this->products_ordered_attributes = '';
                if (isset ( $order->products [$i] ['attributes'] )) {
                    $attributes_exist = '1';
                    for($j = 0, $n2 = sizeof ( $order->products [$i] ['attributes'] ); $j < $n2; $j ++) {
                        $this->products_ordered_attributes .= "\n\t" . $order->products [$i] ['attributes'] [$j] ['option'] . ' ' . zen_decode_specialchars ( $order->products [$i] ['attributes'] [$j] ['value'] );
                    }
                }
                $order->products_ordered .= $order->products [$i] ['qty'] . ' x ' . $order->products [$i] ['name'] . ($order->products [$i] ['model'] != '' ? ' (' . $order->products [$i] ['model'] . ') ' : '') . ' = ' . $currencies->display_price ( $order->products [$i] ['final_price'], $order->products [$i] ['tax'], $order->products [$i] ['qty'] ) . ($order->products [$i] ['onetime_charges'] != 0 ? "\n" . TEXT_ONETIME_CHARGES_EMAIL . $currencies->display_price ( $this->products [$i] ['onetime_charges'], $order->products [$i] ['tax'], 1 ) : '') . $this->products_ordered_attributes . "\n";
                $order->products_ordered_html .= '<tr>' . "\n" . '<td class="product-details" align="right" valign="top" width="30">' . $order->products [$i] ['qty'] . '&nbsp;x</td>' . "\n" . '<td class="product-details" valign="top">' . nl2br ( $order->products [$i] ['name'] ) . ($order->products [$i] ['model'] != '' ? ' (' . nl2br ( $order->products [$i] ['model'] ) . ') ' : '') . "\n" . '<nobr>' . '<small><em> ' . nl2br ( $this->products_ordered_attributes ) . '</em></small>' . '</nobr>' . '</td>' . "\n" . '<td class="product-details-num" valign="top" align="right">' . $currencies->display_price ( $order->products [$i] ['final_price'], $order->products [$i] ['tax'], $order->products [$i] ['qty'] ) . ($order->products [$i] ['onetime_charges'] != 0 ? '</td></tr>' . "\n" . '<tr><td class="product-details">' . nl2br ( TEXT_ONETIME_CHARGES_EMAIL ) . '</td>' . "\n" . '<td>' . $currencies->display_price ( $order->products [$i] ['onetime_charges'], $order->products [$i] ['tax'], 1 ) : '') . '</td></tr>' . "\n";
            }
			
			/*for ($i=0; $i<sizeof($order->products)&&$i<=50; $i++) {
					$order->products_ordered.=
				      '<tr>' . "\n" .
				      '<td class="product-details" align="right" valign="top" width="30">' . $order->products[$i]['qty'] . '&nbsp;x</td>' . "\n" .
				      '<td class="product-details" valign="top">' . nl2br($order->products[$i]['name']) . ($order->products[$i]['model'] != '' ? ' (' . nl2br($order->products[$i]['model']) . ') ' : '') . "\n" .
				      '<nobr>' .
				      '<small><em> '. nl2br($order->products_ordered_attributes) .'</em></small>' .
				      '</nobr>' .
				      '</td>' . "\n" .
				      '<td class="product-details-num" valign="top" align="right">' .
				      $currencies->display_price($order->products[$i]['final_price'], $order->products[$i]['tax'], $order->products[$i]['qty']) .
				      ($order->products[$i]['onetime_charges'] !=0 ?
				      '</td></tr>' . "\n" . '<tr><td class="product-details">' . nl2br(TEXT_ONETIME_CHARGES_EMAIL) . '</td>' . "\n" .
				      '<td>' . $currencies->display_price($order->products[$i]['onetime_charges'], $order->products[$i]['tax'], 1) : '') .
				      '</td></tr>' . "\n";
			}*/
			$order->send_order_email($BillNo,2);
			
			if($Succeed == $pay_success_id)
			{
				$url=zen_href_link(FILENAME_CHECKOUT_SUCCESS,'','SSL',true, false).'&order_id='.(int) $BillNo;
			}else
			{
				$paymentinfo_html = 'Waiting processing,  '.$Result;
				$url = HTTP_SERVER . DIR_WS_CATALOG .'index.php?main_page=checkout_payment_ccwonline&ptype=processing&order_id='.(int)$BillNo.'&paymentinfo='.urlencode($paymentinfo_html);

			}
			//判断是不是要3d支付,3D支付代码开始
            if($splitdata['redirect3dUrl']){
                //3d跳转支付代码
                $redirect3dUrl = $splitdata['redirect3dUrl'];
//                $MD = $splitdata['MD'];
//                $paReq = $splitdata['paReq'];
//                $TermUrl = $splitdata['TermUrl'];
//                $orderId = $splitdata['orderId'];
//                $transactionId = $splitdata['transactionId'];
//                $sessionToken = $splitdata['sessionToken'];
//                $str = $redirect3dUrl."?MD=$MD&paReq=$paReq&TermUrl=$TermUrl&orderId=$orderId&transactionId=$transactionId&sessionToken=$sessionToken";
                //$json['success']=$redirect3dUrl;
                //$json['success']=$str;
                $url = $str;
            }
            //3d支付代码结束
	        echo "<script language=\"javascript\">";
            echo "location.href=\"$url\"";
            echo "</script>";
     } else 
     {
     	//支付失败
			$sql_data_array = array (
				'orders_status_id' => $payment_declined,
				'date_added' => 'now()',

				'customer_notified' => 0,
				'comments'=>'error_id:'.$Succeed,
				'orders_id' => (int)$BillNo
			);
			$sql_data_order=array(
				'orders_status'=>$payment_declined
			);
			$order->info['payment_module_code'] ='_ONLINE';
			$order->fields['payment_method'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['title'] = MODULE_PAYMENT_CCWONLINE_TEXT_CATALOG_TITLE;
			$order->info['order_status']=$payment_declined;
			zen_db_perform(TABLE_ORDERS, $sql_data_order, 'update', 'orders_id=' . (int) $BillNo);
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array, 'insert' );
			//zen_redirect(zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO,'','SSL') . '&order_id=' . $BillNo);//支付失败
			// $url=zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO,'','SSL',true,false).'&order_id='.(int) $BillNo;
			$paymentinfo_html = '  '.$Result;
			$url = HTTP_SERVER . DIR_WS_CATALOG .'index.php?main_page=checkout_payment_ccwonline&ptype=fail&order_id='.(int)$BillNo.'&paymentinfo='.urlencode($paymentinfo_html);
			
	         echo "<script language=\"javascript\">";
            echo "location.href=\"$url\"";
            echo "</script>";
 		}
	}else
	{
		//md5error
	
	$sql_data_array = array (
				'orders_status_id' => $payment_declined,
				'date_added' => 'now()',
				'customer_notified' => 0,
				'comments'=>'error_id:'.$Succeed,
				'orders_id' => (int)$BillNo
			);
	$sql_data_order=array(
				'orders_status'=>$payment_declined
			);
	zen_db_perform(TABLE_ORDERS,$sql_data_order,'update','orders_id='.(int) $BillNo);
	zen_db_perform(TABLE_ORDERS_STATUS_HISTORY,$sql_data_array, 'insert'  );
	//zen_redirect(zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO,'','SSL',true, false).'&order_id='.(int) $BillNo);//签名错误
	// $url=zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO,'','SSL',true,false).'&order_id='.(int) $BillNo;
	//改为到专门的支付失败说明 页面
	$paymentinfo_html = 'Md5error, '.$Result.'  error_id:'.$Succeed;
	$url = HTTP_SERVER . DIR_WS_CATALOG .'index.php?main_page=checkout_payment_ccwonline&ptype=fail&order_id='.(int)$BillNo.'&paymentinfo='.urlencode($paymentinfo_html);

            echo "<script language=\"javascript\">";
            echo "location.href=\"$url\"";
            echo "</script>";
			exit;
			
	}
	}else
			{
			die("禁止调用！");
			}
	}
	/**生成订单后执行的方法(第二执行方法)
	 *
	 *(这个方法在includes/modules/checkout_process.php页面调用)
	 */
	function after_order_create($insert_id) {
	die("after_order_create");
	}
 
  function before_process() {
  	die("error");
	}

	/**(第三执行的方法)
	 **后处理活动
	 *当从处理器订单的回报，如果秒是成功的，这家以成果地位的历史，并记录为今后参考的数据
	?* @返回布尔
	 */
	function after_process() {
   	return false;
	}

	/**
	*检查引荐
	*zf_domain
	* @帕拉姆字符串$
	* @返回布尔
	*/
	function check_referrer($zf_domain) {
		return true;
	}
    function output_error() {
    	return false;
	}
	/**
	**建设管理页组件
	* @帕拉姆廉政$ zf_order_id
	* @返回字符串
	  */
	function admin_notification($zf_order_id) {
}

	/**安装模块
	 *
	 */
	function install() {
		global $db, $language, $module_type;
		if (!defined('MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_1_1')) {
			include (DIR_FS_CATALOG_LANGUAGES . $_SESSION['language'] . '/modules/' . $module_type . '/' . $this->code . '.php');
		}
		
		//支付地址(正式)
		$action_URL="https://www.win4mall.com/onlinepayByWin";
		$obj=$db->Execute("SELECT max( `orders_status_id` ) as maxid FROM ".TABLE_ORDERS_STATUS);
		$maxid=(int)$obj->fields['maxid'];
		$this->order_status = $maxid+1;
		foreach($this->pay_status as $val){
			$maxid++;
			$index=1;
			foreach($val as $val1){
				$db->Execute("insert into ".TABLE_ORDERS_STATUS."(orders_status_id,language_id,orders_status_name) values(".$maxid.",".$index.",'".$val1."')");
				$index++;
			}
			//$db->Execute("insert into ".TABLE_ORDERS_STATUS."(orders_status_id,language_id,orders_status_name) values(".$maxid.",".$index.",'".$val1."')");

		}
		// add languages support v4.2
		//$lanid=$db->Execute("SELECT * FROM ".TABLE_LANGUAGES." where `directory`'=>'".$_SESSION['language']."'" );
		//$lan_id=$lanid->fields['languages_id'];
		$lan_k=0;
		$querylan=mysql_query("SELECT * FROM ".TABLE_LANGUAGES."");
        while($resutlan = mysql_fetch_array($querylan))
        {
          $lan_id=$resutlan['languages_id'];
		  if($lan_k==0){
		  $db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=831 ");
		  $db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=820 ");
		  $db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=819 ");
		  }
		$db->Execute("insert into ".TABLE_ORDERS_STATUS."(orders_status_id,language_id,orders_status_name) values(831,$lan_id,'payment declined')");
		$db->Execute("insert into ".TABLE_ORDERS_STATUS."(orders_status_id,language_id,orders_status_name) values(820,$lan_id,'not payment')");
		$db->Execute("insert into ".TABLE_ORDERS_STATUS."(orders_status_id,language_id,orders_status_name) values(819,$lan_id,'payment pending')");
		$lan_k++;
	    }
		// END add languages support v4.2
	
		//模块安装状态
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_1_1 . "','MODULE_PAYMENT_CCWONLINE_STATUS','True','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_1_2 . "','6','0','zen_cfg_select_option(array(\'True\', \'False\'), ',now())");
		//商户编号
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_2_1 . "','MODULE_PAYMENT_CCWONLINE_SELLER','8686','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_2_2 . "','6','2',now())");
		//md5key
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_3_1 . "','MODULE_PAYMENT_CCWONLINE_MD5KEY','Umd5key','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_3_2 . "','6','4',now())");
		// //币种
		// $db->Execute("insert into " . TABLE_CONFIGURATION .
		// "(configuration_title,configuration_key,configuration_value," .
		// "configuration_description,configuration_group_id,sort_order,set_function,date_added" .
		// ") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_4_1 . "','MODULE_PAYMENT_CCWONLINE_MONEYTYPE','USD','" .
		// MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_4_2 . "','6','6','zen_cfg_select_option(array(\'USD\', \'EUR\',\'CNY\',\'GBP\',\'JPY\',\'AUD\',\'CAD\'), ',now())");
		//语言
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_5_1 . "','MODULE_PAYMENT_CCWONLINE_LANGUAGE','2','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_5_2 . "','6','6','zen_cfg_select_option(array(\'1\', \'2\', \'3\',\'4\',\'5\'), ',now())");
		//区域
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,use_function,set_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_6_1 . "','MODULE_PAYMENT_CCWONLINE_ZONE','0','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_6_2 . "','6','6','zen_get_zone_class_title','zen_cfg_pull_down_zone_classes(',now())");
		//订单状态描述
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,use_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_7_1 . "','MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_ID','820','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_7_2 . "','6','8','zen_cfg_pull_down_order_statuses(','zen_get_order_status_name',now())");
		//订单完成状态描述
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,use_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_11_1 . "','MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_FILISHED_ID','2','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_11_2 . "','6','8','zen_cfg_pull_down_order_statuses(','zen_get_order_status_name',now())");
		//排序
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_8_1 . "','MODULE_PAYMENT_CCWONLINE_SOTR_ORDER','0','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_8_2 . "','6','10',now())");
		//支付接口
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_9_1 . "','MODULE_PAYMENT_CCWONLINE_HANDLER','".$action_URL."','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_9_2 . "','6','12',now())");
		//返回地址
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_10_1 . "','MODULE_PAYMENT_CCWONLINE_RETURN_URL','" . HTTP_SERVER .DIR_WS_CATALOG. "index.php?main_page=checkout_payment_ccwonline','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_10_2 . "','6','12',now())");

		//开启cdn 使用js定位客户ip
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_1 . "','MODULE_PAYMENT_CCWONLINE_CDNJS','False','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_13_2 . "','6','12','zen_cfg_select_option(array(\'True\', \'False\'), ',now())");

		//选择支持的卡种
		$db->Execute("insert into " . TABLE_CONFIGURATION .
		"(configuration_title,configuration_key,configuration_value," .
		"configuration_description,configuration_group_id,sort_order,set_function,date_added" .
		") values('" . MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_1 . "','MODULE_PAYMENT_CCWONLINE_CARDTYPE','visa, master, jcb','" .
		MODULE_PAYMENT_CCWONLINE_TEXT_CONFIG_14_2 . "','6','12','zen_cfg_select_multioption(array(\'visa\', \'master\', \'jcb\', \'ae\'), ',now())");


	}

	/**卸载模块
	 *
	 */
	function remove() {
		global $db;
		$db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key like 'MODULE_PAYMENT_CCWONLINE%'");
		$db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=831 ");
		$db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=820 ");
		$db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_id=819 ");
		foreach($this->pay_status as $val){
			foreach($val as $val1){
				$db->Execute("delete from ".TABLE_ORDERS_STATUS." where orders_status_name'=>'".$val1."'");
			}
		}
	}

	/**检查是否已安装return 0 or 1
	 *
	 */
	function check() {
		global $db;
		if (!isset ($this->_check)) {
			$curleck_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_CCWONLINE_STATUS'");
			$this->_check = $curleck_query->RecordCount();
		}
		return $this->_check;
	}
	/**设置安装模块的coufiguration_key信息
	 *(*内部配置项列表的模块的配置使用
	 *@返回数组)
	 */
	function keys() {
	 		return array (
			'MODULE_PAYMENT_CCWONLINE_STATUS', //模块状态
			'MODULE_PAYMENT_CCWONLINE_SELLER', //商户账号
			'MODULE_PAYMENT_CCWONLINE_MD5KEY', //md5key
			//'MODULE_PAYMENT_CCWONLINE_MONEYTYPE', //币种
			'MODULE_PAYMENT_CCWONLINE_ZONE', //区域
			'MODULE_PAYMENT_CCWONLINE_LANGUAGE', //语言
			'MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_ID', //订单状态id
			'MODULE_PAYMENT_CCWONLINE_ORDER_STATUS_FILISHED_ID', //订单完成状态
			'MODULE_PAYMENT_CCWONLINE_SOTR_ORDER', //排序
			'MODULE_PAYMENT_CCWONLINE_HANDLER', //支付地址
			'MODULE_PAYMENT_CCWONLINE_RETURN_URL', //返回地址
			'MODULE_PAYMENT_CCWONLINE_CDNJS', //cdn js
			'MODULE_PAYMENT_CCWONLINE_CARDTYPE' //cardtype

		);
	}
   //直连
  function curlPost($url, $data)                                                       
	{    
	 		$ssl = substr($url, 0, 8) == "https://" ? TRUE : FALSE;                        
	        $wesite =$_SERVER['HTTP_HOST'];		   
	        $ch = curl_init();
	        curl_setopt($ch, CURLOPT_URL ,$url);
    	    curl_setopt($ch, CURLOPT_POST,1);                                              
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);                                   
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);                                   
			curl_setopt($ch, CURLOPT_REFERER,$wesite);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_USERAGENT,$_SERVER['HTTP_USER_AGENT']);
			 $data = curl_exec($ch);
	    	curl_close($ch);
			return $data;                                                                  
	}
function uuid() {
 				 if (function_exists ( 'com_create_guid' )) {
		        return com_create_guid ();
		    	} else {
		        mt_srand ( ( double ) microtime () * 10000 ); //optional for php 4.2.0 and up.随便数播种，4.2.0以后不需要了。
		        $charid = strtoupper ( md5 ( uniqid ( rand (), true ) ) ); //根据当前时间（微秒计）生成唯一id.
		        $hyphen = chr ( 45 ); // "-"
		        $token = '' . //chr(123)// "{"
				substr ( $charid, 0, 8 ) . $hyphen . substr ( $charid, 8, 4 ) . $hyphen . substr ( $charid, 12, 4 ) . $hyphen . substr ( $charid, 16, 4 ) . $hyphen . substr ( $charid, 20, 12 );
		        //.chr(125);// "}"
		        return  $token;
		    }
		}

//function write_log($msg){
//  $val = realpath(dirname(DIR_FS_SQL_CACHE.'/').'/logs');
// 		error_log(date("[Y-m-d H:i:s]")."\t" .$msg ."\r\n", 3,$val.'/winpay'.date("[Y-m-d]").'.log');
//	return true;
//}	
}
?>