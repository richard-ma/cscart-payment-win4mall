<?php
?>
<div class="centerColumn" id="checkoutSuccess">

<h1 id="checkoutSuccessHeading">
<?php if ($messageStack->size('checkout_payresult') > 0) echo $messageStack->output('checkout_payresult'); ?>
</h1>

<div>
<?php if ($messageStack->size('checkout_payresult_info') > 0) echo $messageStack->output('checkout_payresult_info'); ?>
	
</div>
<!--bof logoff-->
<div id="checkoutSuccessLogoff">
 
</div>
<!--eof logoff-->
<h3 id="checkoutSuccessThanks" class="centeredContent"><?php echo 'thank you for shopping'; ?></h3>
</div>
